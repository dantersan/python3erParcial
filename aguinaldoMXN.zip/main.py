def calcular_aguinaldo(salario_diario, dias_trabajados):
    """
    Calcula el aguinaldo proporcional con la fórmula:
    aguinaldo = (15/365) * dias_trabajados * salario_diario
    """
    aguinaldo = (15 / 365) * dias_trabajados * salario_diario
    return round(aguinaldo, 2)

# Solicitar datos al usuario
salario_diario = 300  # Salario diario fijo en MXN
dias_trabajados = 254  # Días trabajados en el año

# Calcular aguinaldo
aguinaldo = calcular_aguinaldo(salario_diario, dias_trabajados)

# Imprimir resultado
print(f"El aguinaldo proporcional es: ${aguinaldo} MXN")