import json
import csv
import datetime

def generar_numero_factura():
    return datetime.datetime.now().strftime("%Y%m%d%H%M%S")

def solicitar_datos():
    cliente = input("Nombre del cliente: ")
    productos = []
    while True:
        nombre = input("Nombre del producto (o 'fin' para terminar): ")
        if nombre.lower() == 'fin':
            break
        cantidad = int(input("Cantidad: "))
        precio = float(input("Precio unitario: "))
        productos.append({"nombre": nombre, "cantidad": cantidad, "precio": precio})
    
    descuento = float(input("Descuento a aplicar (%): "))
    metodo_pago = input("Método de pago (1. Efectivo, 2. Tarjeta, 3. PayPal): ")
    return cliente, productos, descuento, metodo_pago

def calcular_factura(productos, descuento):
    subtotal = sum(p['cantidad'] * p['precio'] for p in productos)
    descuento_aplicado = (subtotal * descuento) / 100
    subtotal_descuento = subtotal - descuento_aplicado
    impuestos = subtotal_descuento * 0.16
    total = subtotal_descuento + impuestos
    return subtotal, descuento_aplicado, impuestos, total

def imprimir_factura(cliente, productos, subtotal, descuento_aplicado, impuestos, total, numero_factura, metodo_pago):
    print("\n--- FACTURA ---")
    print(f"Número de Factura: {numero_factura}")
    print(f"Cliente: {cliente}")
    print("Productos:")
    for p in productos:
        print(f"- {p['nombre']} x{p['cantidad']} - ${p['precio']:.2f} c/u")
    print(f"Subtotal: ${subtotal:.2f}")
    print(f"Descuento: -${descuento_aplicado:.2f}")
    print(f"Impuestos (IVA 16%): ${impuestos:.2f}")
    print(f"Total a pagar: ${total:.2f}")
    print(f"Método de Pago: {['Efectivo', 'Tarjeta', 'PayPal'][int(metodo_pago)-1]}")

def guardar_factura_txt(cliente, productos, subtotal, descuento_aplicado, impuestos, total, numero_factura, metodo_pago):
    filename = f"factura_{numero_factura}.txt"
    with open(filename, "w") as f:
        f.write(f"Número de Factura: {numero_factura}\n")
        f.write(f"Cliente: {cliente}\n")
        f.write("Productos:\n")
        for p in productos:
            f.write(f"- {p['nombre']} x{p['cantidad']} - ${p['precio']:.2f} c/u\n")
        f.write(f"Subtotal: ${subtotal:.2f}\n")
        f.write(f"Descuento: -${descuento_aplicado:.2f}\n")
        f.write(f"Impuestos (IVA 16%): ${impuestos:.2f}\n")
        f.write(f"Total a pagar: ${total:.2f}\n")
        f.write(f"Método de Pago: {['Efectivo', 'Tarjeta', 'PayPal'][int(metodo_pago)-1]}\n")

def exportar_json(cliente, productos, subtotal, descuento_aplicado, impuestos, total, numero_factura, metodo_pago):
    data = {
        "numero_factura": numero_factura,
        "cliente": cliente,
        "productos": productos,
        "subtotal": subtotal,
        "descuento_aplicado": descuento_aplicado,
        "impuestos": impuestos,
        "total": total,
        "metodo_pago": ['Efectivo', 'Tarjeta', 'PayPal'][int(metodo_pago)-1]
    }
    filename = f"factura_{numero_factura}.json"
    with open(filename, "w") as f:
        json.dump(data, f, indent=4)

def exportar_csv(cliente, productos, subtotal, descuento_aplicado, impuestos, total, numero_factura, metodo_pago):
    filename = f"factura_{numero_factura}.csv"
    with open(filename, "w", newline="") as f:
        writer = csv.writer(f)
        writer.writerow(["Número de Factura", "Cliente", "Producto", "Cantidad", "Precio Unitario", "Subtotal", "Descuento", "Impuestos", "Total", "Método de Pago"])
        for p in productos:
            writer.writerow([numero_factura, cliente, p['nombre'], p['cantidad'], p['precio'], subtotal, descuento_aplicado, impuestos, total, ['Efectivo', 'Tarjeta', 'PayPal'][int(metodo_pago)-1]])

def main():
    cliente, productos, descuento, metodo_pago = solicitar_datos()
    numero_factura = generar_numero_factura()
    subtotal, descuento_aplicado, impuestos, total = calcular_factura(productos, descuento)
    imprimir_factura(cliente, productos, subtotal, descuento_aplicado, impuestos, total, numero_factura, metodo_pago)
    guardar_factura_txt(cliente, productos, subtotal, descuento_aplicado, impuestos, total, numero_factura, metodo_pago)
    exportar_json(cliente, productos, subtotal, descuento_aplicado, impuestos, total, numero_factura, metodo_pago)
    exportar_csv(cliente, productos, subtotal, descuento_aplicado, impuestos, total, numero_factura, metodo_pago)
    print("Factura guardada en formatos TXT, JSON y CSV.")

if __name__ == "__main__":
    main()

